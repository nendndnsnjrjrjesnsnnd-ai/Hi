# AuthLobby Suite (7 bağımsız eklenti, 0 skript)
Gereksinim: Paper 1.21.6+ , Java 21. Derleme: `mvn clean package` (her modülün target/ klasöründe jar çıkar).
Kurulum: AuthCore zorunlu; diğerleri isteğe bağlı, hepsini plugins/ içine at.
1 AuthCore – kayıt/giriş, Dialog UI, SQLite, PBKDF2 hash, API+eventler
2 AuthProtect – girişsiz hareket/blok/komut/sohbet/envanter kısıtı
3 AuthLobby – lobiye ışınlama (/setauthlobby), gamemode, oyuncu gizleme, girişte eski konuma dönüş
4 AuthSession – IP tabanlı otomatik giriş
5 AuthSecurity – deneme limiti/kilit, şifre kuralları, giriş zaman aşımı
6 AuthUI – title, bossbar, actionbar, ses, kör efekti
7 AuthTransfer – giriş/kayıttan sonra "AKTARILIYORSUN" 3-2-1 geri sayımı (oyuncu donar), sonra ana sunucuya gönderir
Komutlar: /login /register /changepassword /logout /authadmin <reload|unregister|forcelogin>

## İstemci sürümüne göre davranış
- 1.21.6+ istemci -> Dialog menüsü (komut da çalışır)
- 1.21.5 ve altı (ViaVersion + ViaBackwards ile girenler) -> menü yok, sadece komut: /login şifre , /kayıt şifre şifre
  (sürüm tespiti için sunucuda ViaVersion kurulu olmalı; kurulu değilse herkes menü alır)
- Giriş yapmamış oyuncu: hareket yok, /server dahil hiçbir komut yok (sadece login/kayıt komutları).
  Velocity/Bungee'nin kendi /server komutunu backend engelleyemez -> proxy tarafında yetkiyi kapat (README sonu).
