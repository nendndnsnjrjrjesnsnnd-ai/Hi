package dev.authlobby.authcore;
import java.util.UUID;
import org.bukkit.entity.Player;
/** Diğer eklentiler: Bukkit.getServicesManager().load(AuthApi.class) */
public interface AuthApi {
    boolean isAuthenticated(UUID id);
    default boolean isAuthenticated(Player p) { return isAuthenticated(p.getUniqueId()); }
    void forceLogin(Player p, String method);
    void logout(Player p);
    /** true: 1.21.6+ istemci, Dialog menüsü gösterilir. false: eski sürüm, sadece komut. */
    boolean usesDialog(Player p);
}
