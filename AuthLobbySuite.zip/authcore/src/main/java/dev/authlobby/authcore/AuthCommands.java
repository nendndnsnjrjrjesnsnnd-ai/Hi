package dev.authlobby.authcore;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
final class AuthCommands implements CommandExecutor, TabCompleter {
    private final AuthCore plugin; private final AuthManager mgr;
    AuthCommands(AuthCore plugin, AuthManager mgr) { this.plugin = plugin; this.mgr = mgr; }
    @Override public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        String n = cmd.getName().toLowerCase();
        if (n.equals("authadmin")) return admin(s, a);
        if (!(s instanceof Player p)) { s.sendMessage("Sadece oyuncular."); return true; }
        switch (n) {
            case "login" -> { if (a.length != 1) p.sendMessage(plugin.msg("usage-login")); else mgr.attemptLogin(p, a[0]); }
            case "register" -> { if (a.length != 2) p.sendMessage(plugin.msg("usage-register")); else mgr.attemptRegister(p, a[0], a[1]); }
            case "changepassword" -> {
                if (!mgr.isAuthenticated(p)) p.sendMessage(plugin.msg("must-login"));
                else if (a.length != 2) p.sendMessage(plugin.msg("usage-change"));
                else mgr.changePassword(p, a[0], a[1]);
            }
            case "logout" -> { if (!mgr.isAuthenticated(p)) p.sendMessage(plugin.msg("must-login")); else mgr.logout(p); }
        }
        return true;
    }
    private boolean admin(CommandSender s, String[] a) {
        if (!s.hasPermission("authlobby.admin")) { s.sendMessage(plugin.msg("no-permission")); return true; }
        if (a.length == 1 && a[0].equalsIgnoreCase("reload")) { plugin.reloadConfig(); s.sendMessage(plugin.msg("reloaded")); return true; }
        if (a.length == 2 && a[0].equalsIgnoreCase("unregister")) {
            OfflinePlayer op = Bukkit.getOfflinePlayer(a[1]); mgr.unregister(op.getUniqueId());
            s.sendMessage(plugin.msg("admin-done")); return true;
        }
        if (a.length == 2 && a[0].equalsIgnoreCase("forcelogin")) {
            Player t = Bukkit.getPlayerExact(a[1]);
            if (t == null) { s.sendMessage(plugin.msg("admin-notfound")); return true; }
            mgr.forceLogin(t, "admin"); s.sendMessage(plugin.msg("admin-done")); return true;
        }
        s.sendMessage(plugin.msg("usage-admin")); return true;
    }
    @Override public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        if (c.getName().equalsIgnoreCase("authadmin") && a.length == 1) return List.of("reload", "unregister", "forcelogin");
        return List.of();
    }
}
