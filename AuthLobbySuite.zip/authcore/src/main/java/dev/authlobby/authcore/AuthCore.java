package dev.authlobby.authcore;
import java.util.List;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.*;
import org.bukkit.plugin.ServicePriority;
import org.bukkit.plugin.java.JavaPlugin;
public final class AuthCore extends JavaPlugin implements Listener {
    private static final MiniMessage MM = MiniMessage.miniMessage();
    private Database db; private AuthManager manager;
    @Override public void onEnable() {
        try { Class.forName("io.papermc.paper.dialog.Dialog"); }
        catch (ClassNotFoundException e) { getLogger().severe("Bu eklenti Paper 1.21.6+ (Dialog API) gerektirir!"); getServer().getPluginManager().disablePlugin(this); return; }
        saveDefaultConfig();
        try { db = new Database(getDataFolder()); }
        catch (Exception e) { getLogger().severe("Veritabanı açılamadı: " + e.getMessage()); getServer().getPluginManager().disablePlugin(this); return; }
        manager = new AuthManager(this, db);
        getServer().getServicesManager().register(AuthApi.class, manager, this, ServicePriority.Normal);
        getServer().getPluginManager().registerEvents(this, this);
        AuthCommands cmds = new AuthCommands(this, manager);
        for (String c : List.of("login", "register", "changepassword", "logout", "authadmin")) {
            getCommand(c).setExecutor(cmds); getCommand(c).setTabCompleter(cmds);
        }
        for (Player p : Bukkit.getOnlinePlayers()) manager.handleJoin(p);
    }
    @Override public void onDisable() {
        getServer().getServicesManager().unregisterAll(this);
        if (db != null) db.close();
    }
    public String raw(String key) { return getConfig().getString("messages." + key, key); }
    public Component msg(String key, String... kv) {
        String s = raw(key);
        for (int i = 0; i + 1 < kv.length; i += 2) s = s.replace("{" + kv[i] + "}", kv[i + 1]);
        boolean noPrefix = key.startsWith("dialog-") || key.startsWith("kick-");
        return MM.deserialize((noPrefix ? "" : raw("prefix")) + s);
    }
    @EventHandler public void onPreLogin(AsyncPlayerPreLoginEvent e) {
        for (Player p : Bukkit.getOnlinePlayers())
            if (p.getName().equalsIgnoreCase(e.getName()) && !p.getUniqueId().equals(e.getUniqueId())) {
                e.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER, msg("kick-duplicate")); return;
            }
    }
    @EventHandler public void onJoin(PlayerJoinEvent e) { manager.handleJoin(e.getPlayer()); }
    @EventHandler public void onQuit(PlayerQuitEvent e) { manager.handleQuit(e.getPlayer().getUniqueId()); }
}
