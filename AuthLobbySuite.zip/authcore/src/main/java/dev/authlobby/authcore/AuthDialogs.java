package dev.authlobby.authcore;
import dev.authlobby.authcore.event.AuthType;
import io.papermc.paper.dialog.Dialog;
import io.papermc.paper.registry.data.dialog.ActionButton;
import io.papermc.paper.registry.data.dialog.DialogBase;
import io.papermc.paper.registry.data.dialog.action.DialogAction;
import io.papermc.paper.registry.data.dialog.body.DialogBody;
import io.papermc.paper.registry.data.dialog.input.DialogInput;
import io.papermc.paper.registry.data.dialog.type.DialogType;
import java.time.Duration;
import java.util.*;
import net.kyori.adventure.text.event.ClickCallback;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
final class AuthDialogs {
    private AuthDialogs() {}
    static void show(AuthCore plugin, AuthManager mgr, Player p, AuthType type, String error) {
        if (type == AuthType.REGISTER && mgr.needsRules(p)) { showRules(plugin, mgr, p); return; }
        boolean login = type == AuthType.LOGIN;
        List<DialogBody> body = new ArrayList<>();
        if (!plugin.raw(login ? "dialog-login-body" : "dialog-register-body").isBlank())
            body.add(DialogBody.plainMessage(plugin.msg(login ? "dialog-login-body" : "dialog-register-body")));
        if (error != null && !error.isBlank()) body.add(DialogBody.plainMessage(MiniMessage.miniMessage().deserialize("<red>" + error)));
        List<DialogInput> inputs = new ArrayList<>();
        inputs.add(DialogInput.text("password", plugin.msg(login ? "dialog-login-password" : "dialog-password")).width(250).maxLength(64).build());
        if (!login) inputs.add(DialogInput.text("password2", plugin.msg("dialog-password-repeat")).width(250).maxLength(64).build());
        ClickCallback.Options opts = ClickCallback.Options.builder().uses(ClickCallback.UNLIMITED_USES).lifetime(Duration.ofHours(1)).build();
        ActionButton main = ActionButton.builder(plugin.msg(login ? "dialog-login-button" : "dialog-register-button")).width(120)
            .action(DialogAction.customClick((view, aud) -> {
                if (!(aud instanceof Player pl)) return;
                String a = Optional.ofNullable(view.getText("password")).orElse("");
                String b = Optional.ofNullable(view.getText("password2")).orElse("");
                Bukkit.getScheduler().runTask(plugin, () -> { if (login) mgr.attemptLogin(pl, a); else mgr.attemptRegister(pl, a, b); });
            }, opts)).build();
        ActionButton quit = ActionButton.builder(plugin.msg("dialog-quit-button")).width(120)
            .action(DialogAction.customClick((view, aud) -> {
                if (aud instanceof Player pl) Bukkit.getScheduler().runTask(plugin, () -> pl.kick(plugin.msg("kick-quit")));
            }, opts)).build();
        List<ActionButton> btns = new ArrayList<>(List.of(main));
        if (!plugin.raw("dialog-quit-button").isBlank()) btns.add(quit);
        Dialog dialog = Dialog.create(f -> f.empty()
            .base(DialogBase.builder(plugin.msg(login ? "dialog-login-title" : "dialog-register-title"))
                .canCloseWithEscape(false).body(body).inputs(inputs).build())
            .type(DialogType.multiAction(btns, null, btns.size())));
        p.showDialog(dialog);
    }
    /** Kayıttan önce: kuralları kabul et / etme ekranı. */
    static void showRules(AuthCore plugin, AuthManager mgr, Player p) {
        MiniMessage mm = MiniMessage.miniMessage();
        List<DialogBody> body = new ArrayList<>();
        for (String l : plugin.getConfig().getStringList("rules.lines")) body.add(DialogBody.plainMessage(mm.deserialize(l)));
        ClickCallback.Options opts = ClickCallback.Options.builder().uses(ClickCallback.UNLIMITED_USES).lifetime(Duration.ofHours(1)).build();
        ActionButton yes = ActionButton.builder(mm.deserialize(plugin.getConfig().getString("rules.accept-button", "Kabul"))).width(140)
            .action(DialogAction.customClick((view, aud) -> {
                if (aud instanceof Player pl) Bukkit.getScheduler().runTask(plugin, () -> { mgr.acceptRules(pl.getUniqueId()); show(plugin, mgr, pl, AuthType.REGISTER, null); });
            }, opts)).build();
        ActionButton no = ActionButton.builder(mm.deserialize(plugin.getConfig().getString("rules.decline-button", "Reddet"))).width(140)
            .action(DialogAction.customClick((view, aud) -> {
                if (aud instanceof Player pl) Bukkit.getScheduler().runTask(plugin, () -> pl.kick(plugin.msg("kick-quit")));
            }, opts)).build();
        Dialog d = Dialog.create(f -> f.empty()
            .base(DialogBase.builder(mm.deserialize(plugin.getConfig().getString("rules.title", "Kurallar"))).canCloseWithEscape(false).body(body).build())
            .type(plugin.getConfig().getString("rules.decline-button", "").isBlank() ? DialogType.notice(yes) : DialogType.confirmation(yes, no)));
        p.showDialog(d);
    }
}
