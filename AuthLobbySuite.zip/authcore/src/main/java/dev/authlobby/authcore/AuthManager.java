package dev.authlobby.authcore;
import dev.authlobby.authcore.event.*;
import java.sql.SQLException;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
public final class AuthManager implements AuthApi {
    private final AuthCore plugin; private final Database db;
    private final Set<UUID> authed = ConcurrentHashMap.newKeySet();
    private final Set<UUID> rulesOk = ConcurrentHashMap.newKeySet();
    AuthManager(AuthCore plugin, Database db) { this.plugin = plugin; this.db = db; }

    @Override public boolean isAuthenticated(UUID id) { return authed.contains(id); }
    @Override public void forceLogin(Player p, String method) {
        if (!authed.add(p.getUniqueId())) return;
        finish(p, method);
        if (!method.equals("register")) async(() -> { try { db.touch(p.getUniqueId(), ip(p)); } catch (SQLException e) { log(e); } });
    }
    @Override public boolean usesDialog(Player p) {
        if (plugin.getConfig().getBoolean("force-commands", false)) return false;
        return ClientVersion.protocol(p) >= plugin.getConfig().getInt("dialog-min-protocol", 771); // 771 = 1.21.6
    }
    @Override public void logout(Player p) {
        if (authed.remove(p.getUniqueId())) {
            Bukkit.getPluginManager().callEvent(new PlayerLogoutEvent(p));
            handleJoin(p);
        }
    }
    void handleQuit(UUID id) { authed.remove(id); rulesOk.remove(id); }
    void acceptRules(UUID id) { rulesOk.add(id); }
    boolean needsRules(Player p) {
        return usesDialog(p) && plugin.getConfig().getBoolean("rules.enabled", true) && !rulesOk.contains(p.getUniqueId());
    }

    void handleJoin(Player p) {
        async(() -> {
            boolean reg;
            try { reg = db.exists(p.getUniqueId()); }
            catch (SQLException e) { log(e); sync(() -> p.kick(plugin.msg("db-error"))); return; }
            final boolean registered = reg;
            sync(() -> {
                if (!p.isOnline()) return;
                Bukkit.getPluginManager().callEvent(new AuthRequiredEvent(p, registered));
                if (!isAuthenticated(p) && p.isOnline()) {
                    if (usesDialog(p)) AuthDialogs.show(plugin, this, p, registered ? AuthType.LOGIN : AuthType.REGISTER, null);
                    if (!registered && !usesDialog(p) && plugin.getConfig().getBoolean("rules.enabled", true))
                        for (String l : plugin.getConfig().getStringList("rules.lines")) p.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(l));
                    p.sendMessage(plugin.msg(registered ? "usage-login" : "usage-register"));
                }
            });
        });
    }

    public void attemptLogin(Player p, String pw) {
        if (isAuthenticated(p)) { p.sendMessage(plugin.msg("already-logged")); return; }
        AuthPreAttemptEvent pre = new AuthPreAttemptEvent(p, AuthType.LOGIN);
        Bukkit.getPluginManager().callEvent(pre);
        if (pre.isCancelled()) { feedback(p, AuthType.LOGIN, pre.getReason()); return; }
        async(() -> {
            boolean ok = false;
            try { String h = db.hash(p.getUniqueId()); ok = h != null && Passwords.verify(pw, h); }
            catch (SQLException e) { log(e); }
            final boolean success = ok;
            sync(() -> {
                if (!p.isOnline()) return;
                Bukkit.getPluginManager().callEvent(new AuthResultEvent(p, AuthType.LOGIN, success));
                if (!p.isOnline()) return;
                if (success) forceLogin(p, "login"); else feedback(p, AuthType.LOGIN, plugin.raw("wrong-password"));
            });
        });
    }

    public void attemptRegister(Player p, String pw, String pw2) {
        if (isAuthenticated(p)) { p.sendMessage(plugin.msg("already-logged")); return; }
        if (needsRules(p)) { feedback(p, AuthType.REGISTER, plugin.raw("rules-required")); return; }
        if (!pw.equals(pw2)) { feedback(p, AuthType.REGISTER, plugin.raw("mismatch")); return; }
        String bad = checkPassword(p, pw);
        if (bad != null) { feedback(p, AuthType.REGISTER, bad); return; }
        AuthPreAttemptEvent pre = new AuthPreAttemptEvent(p, AuthType.REGISTER);
        Bukkit.getPluginManager().callEvent(pre);
        if (pre.isCancelled()) { feedback(p, AuthType.REGISTER, pre.getReason()); return; }
        async(() -> {
            String err = null;
            try {
                if (db.exists(p.getUniqueId())) err = plugin.raw("already-registered");
                else db.create(p.getUniqueId(), p.getName(), Passwords.hash(pw), ip(p));
            } catch (SQLException e) { log(e); err = plugin.raw("db-error"); }
            final String error = err;
            sync(() -> {
                if (!p.isOnline()) return;
                Bukkit.getPluginManager().callEvent(new AuthResultEvent(p, AuthType.REGISTER, error == null));
                if (!p.isOnline()) return;
                if (error == null) forceLogin(p, "register"); else feedback(p, AuthType.REGISTER, error);
            });
        });
    }

    public void changePassword(Player p, String old, String neu) {
        String bad = checkPassword(p, neu);
        if (bad != null) { p.sendMessage(plugin.msg("password-rejected", "reason", bad)); return; }
        async(() -> {
            boolean ok = false;
            try {
                String h = db.hash(p.getUniqueId());
                if (h != null && Passwords.verify(old, h)) { db.setHash(p.getUniqueId(), Passwords.hash(neu)); ok = true; }
            } catch (SQLException e) { log(e); }
            final boolean done = ok;
            sync(() -> p.sendMessage(plugin.msg(done ? "password-changed" : "wrong-password")));
        });
    }

    public void unregister(UUID id) {
        async(() -> { try { db.delete(id); } catch (SQLException e) { log(e); } });
        Player online = Bukkit.getPlayer(id);
        if (online != null) { authed.remove(id); sync(() -> online.kick(plugin.msg("unregistered-kick"))); }
    }

    private String checkPassword(Player p, String pw) {
        if (pw.isEmpty()) return plugin.raw("empty-password");
        PasswordCheckEvent ev = new PasswordCheckEvent(p, pw);
        Bukkit.getPluginManager().callEvent(ev);
        return ev.isCancelled() ? (ev.getReason().isBlank() ? plugin.raw("password-rejected-default") : ev.getReason()) : null;
    }

    private void feedback(Player p, AuthType type, String error) {
        if (!p.isOnline()) return;
        p.sendMessage(plugin.msg("error", "error", error));
        if (usesDialog(p)) AuthDialogs.show(plugin, this, p, type, error);
    }
    private void finish(Player p, String method) {
        if (usesDialog(p)) p.closeDialog();
        Bukkit.getPluginManager().callEvent(new PlayerAuthenticatedEvent(p, method));
        p.sendMessage(plugin.msg(method.equals("register") ? "register-success" : "auth-success"));
    }
    private static String ip(Player p) { return p.getAddress() == null ? "unknown" : p.getAddress().getAddress().getHostAddress(); }
    private void async(Runnable r) { Bukkit.getScheduler().runTaskAsynchronously(plugin, r); }
    private void sync(Runnable r) { Bukkit.getScheduler().runTask(plugin, r); }
    private void log(Exception e) { plugin.getLogger().severe("Veritabanı hatası: " + e.getMessage()); }
}
