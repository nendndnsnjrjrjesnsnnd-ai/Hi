package dev.authlobby.authcore;
import java.lang.reflect.Method;
import java.util.UUID;
import org.bukkit.entity.Player;
/** ViaVersion varsa istemci protokolünü okur (yoksa herkes sunucu sürümündedir). */
final class ClientVersion {
    private static Object api; private static Method m; private static boolean init;
    private ClientVersion() {}
    static synchronized int protocol(Player p) {
        try {
            if (!init) {
                init = true;
                Class<?> via = Class.forName("com.viaversion.viaversion.api.Via");
                api = via.getMethod("getAPI").invoke(null);
                m = Class.forName("com.viaversion.viaversion.api.ViaAPI").getMethod("getPlayerVersion", UUID.class);
            }
            if (m == null) return Integer.MAX_VALUE;
            int v = (int) m.invoke(api, p.getUniqueId());
            return Math.max(v, 0); // bilinmiyorsa 0 -> komut modu (güvenli)
        } catch (ClassNotFoundException e) { m = null; return Integer.MAX_VALUE; }
        catch (Throwable t) { return 0; }
    }
}
