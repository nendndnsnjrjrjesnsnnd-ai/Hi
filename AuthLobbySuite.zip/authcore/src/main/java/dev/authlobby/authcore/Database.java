package dev.authlobby.authcore;
import java.io.File;
import java.sql.*;
import java.util.UUID;
final class Database {
    private final Connection c;
    Database(File dir) throws Exception {
        dir.mkdirs();
        try { Class.forName("org.sqlite.JDBC"); } catch (ClassNotFoundException ignored) {}
        c = DriverManager.getConnection("jdbc:sqlite:" + new File(dir, "accounts.db").getAbsolutePath());
        try (Statement s = c.createStatement()) {
            s.execute("CREATE TABLE IF NOT EXISTS accounts(uuid TEXT PRIMARY KEY, name TEXT, hash TEXT NOT NULL, reg_ip TEXT, last_ip TEXT, last_login INTEGER)");
        }
    }
    synchronized String hash(UUID id) throws SQLException {
        try (PreparedStatement s = c.prepareStatement("SELECT hash FROM accounts WHERE uuid=?")) {
            s.setString(1, id.toString());
            try (ResultSet r = s.executeQuery()) { return r.next() ? r.getString(1) : null; }
        }
    }
    boolean exists(UUID id) throws SQLException { return hash(id) != null; }
    synchronized void create(UUID id, String name, String hash, String ip) throws SQLException {
        try (PreparedStatement s = c.prepareStatement("INSERT INTO accounts(uuid,name,hash,reg_ip,last_ip,last_login) VALUES(?,?,?,?,?,?)")) {
            s.setString(1, id.toString()); s.setString(2, name); s.setString(3, hash); s.setString(4, ip); s.setString(5, ip); s.setLong(6, System.currentTimeMillis());
            s.executeUpdate();
        }
    }
    synchronized void touch(UUID id, String ip) throws SQLException {
        try (PreparedStatement s = c.prepareStatement("UPDATE accounts SET last_ip=?, last_login=? WHERE uuid=?")) {
            s.setString(1, ip); s.setLong(2, System.currentTimeMillis()); s.setString(3, id.toString()); s.executeUpdate();
        }
    }
    synchronized void setHash(UUID id, String hash) throws SQLException {
        try (PreparedStatement s = c.prepareStatement("UPDATE accounts SET hash=? WHERE uuid=?")) {
            s.setString(1, hash); s.setString(2, id.toString()); s.executeUpdate();
        }
    }
    synchronized void delete(UUID id) throws SQLException {
        try (PreparedStatement s = c.prepareStatement("DELETE FROM accounts WHERE uuid=?")) { s.setString(1, id.toString()); s.executeUpdate(); }
    }
    synchronized void close() { try { c.close(); } catch (SQLException ignored) {} }
}
