package dev.authlobby.authcore;
import java.security.*;
import java.util.Base64;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
final class Passwords {
    private static final int ITER = 120_000;
    private static final SecureRandom RNG = new SecureRandom();
    private Passwords() {}
    static String hash(String pw) {
        byte[] salt = new byte[16]; RNG.nextBytes(salt);
        return ITER + ":" + Base64.getEncoder().encodeToString(salt) + ":" + Base64.getEncoder().encodeToString(pbkdf2(pw, salt, ITER));
    }
    static boolean verify(String pw, String stored) {
        try {
            String[] p = stored.split(":");
            byte[] expect = Base64.getDecoder().decode(p[2]);
            return MessageDigest.isEqual(expect, pbkdf2(pw, Base64.getDecoder().decode(p[1]), Integer.parseInt(p[0])));
        } catch (Exception e) { return false; }
    }
    private static byte[] pbkdf2(String pw, byte[] salt, int iter) {
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(new PBEKeySpec(pw.toCharArray(), salt, iter, 256)).getEncoded();
        } catch (GeneralSecurityException e) { throw new IllegalStateException(e); }
    }
}
