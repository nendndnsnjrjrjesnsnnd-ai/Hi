package dev.authlobby.authcore.event;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.PlayerEvent;
/** Giriş/kayıt denemesinden önce. İptal edilirse deneme yapılmaz (kilit, rate-limit için). */
public class AuthPreAttemptEvent extends PlayerEvent implements Cancellable {
    private static final HandlerList H = new HandlerList();
    private final AuthType type; private boolean cancelled; private String reason = "";
    public AuthPreAttemptEvent(Player p, AuthType type) { super(p); this.type = type; }
    public AuthType getType() { return type; }
    public String getReason() { return reason; }
    public void setReason(String r) { this.reason = r; }
    @Override public boolean isCancelled() { return cancelled; }
    @Override public void setCancelled(boolean c) { cancelled = c; }
    @Override public HandlerList getHandlers() { return H; }
    public static HandlerList getHandlerList() { return H; }
}
