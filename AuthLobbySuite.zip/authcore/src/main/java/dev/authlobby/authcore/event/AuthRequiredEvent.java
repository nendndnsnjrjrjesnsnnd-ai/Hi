package dev.authlobby.authcore.event;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;
import org.bukkit.event.player.PlayerEvent;
/** Oyuncu girişe ihtiyaç duyduğunda (join / logout) tetiklenir. Dinleyiciler forceLogin yapabilir. */
public class AuthRequiredEvent extends PlayerEvent {
    private static final HandlerList H = new HandlerList();
    private final boolean registered;
    public AuthRequiredEvent(Player p, boolean registered) { super(p); this.registered = registered; }
    public boolean isRegistered() { return registered; }
    @Override public HandlerList getHandlers() { return H; }
    public static HandlerList getHandlerList() { return H; }
}
