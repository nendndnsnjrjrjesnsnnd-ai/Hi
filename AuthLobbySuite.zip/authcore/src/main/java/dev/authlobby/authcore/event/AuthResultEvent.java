package dev.authlobby.authcore.event;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;
import org.bukkit.event.player.PlayerEvent;
public class AuthResultEvent extends PlayerEvent {
    private static final HandlerList H = new HandlerList();
    private final AuthType type; private final boolean success;
    public AuthResultEvent(Player p, AuthType type, boolean success) { super(p); this.type = type; this.success = success; }
    public AuthType getType() { return type; }
    public boolean isSuccess() { return success; }
    @Override public HandlerList getHandlers() { return H; }
    public static HandlerList getHandlerList() { return H; }
}
