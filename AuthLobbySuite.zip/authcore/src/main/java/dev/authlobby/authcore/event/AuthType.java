package dev.authlobby.authcore.event;
public enum AuthType { LOGIN, REGISTER }
