package dev.authlobby.authcore.event;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.PlayerEvent;
/** Yeni şifre kuralları için. İptal edilirse şifre reddedilir. */
public class PasswordCheckEvent extends PlayerEvent implements Cancellable {
    private static final HandlerList H = new HandlerList();
    private final String password; private boolean cancelled; private String reason = "";
    public PasswordCheckEvent(Player p, String password) { super(p); this.password = password; }
    public String getPassword() { return password; }
    public String getReason() { return reason; }
    public void setReason(String r) { this.reason = r; }
    @Override public boolean isCancelled() { return cancelled; }
    @Override public void setCancelled(boolean c) { cancelled = c; }
    @Override public HandlerList getHandlers() { return H; }
    public static HandlerList getHandlerList() { return H; }
}
