package dev.authlobby.authcore.event;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;
import org.bukkit.event.player.PlayerEvent;
public class PlayerAuthenticatedEvent extends PlayerEvent {
    private static final HandlerList H = new HandlerList();
    private final String method;
    public PlayerAuthenticatedEvent(Player p, String method) { super(p); this.method = method; }
    /** login, register, session, admin ... */
    public String getMethod() { return method; }
    @Override public HandlerList getHandlers() { return H; }
    public static HandlerList getHandlerList() { return H; }
}
