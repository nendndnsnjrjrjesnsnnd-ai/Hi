package dev.authlobby.authcore.event;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;
import org.bukkit.event.player.PlayerEvent;
public class PlayerLogoutEvent extends PlayerEvent {
    private static final HandlerList H = new HandlerList();
    public PlayerLogoutEvent(Player p) { super(p); }
    @Override public HandlerList getHandlers() { return H; }
    public static HandlerList getHandlerList() { return H; }
}
