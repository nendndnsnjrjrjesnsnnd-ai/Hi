package dev.authlobby.authlobby;
import dev.authlobby.authcore.AuthApi;
import dev.authlobby.authcore.event.*;
import java.io.File;
import java.io.IOException;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.plugin.java.JavaPlugin;
public final class AuthLobby extends JavaPlugin implements Listener, CommandExecutor {
    private AuthApi api; private File dataFile; private YamlConfiguration data;
    @Override public void onEnable() {
        saveDefaultConfig();
        api = Bukkit.getServicesManager().load(AuthApi.class);
        dataFile = new File(getDataFolder(), "data.yml"); data = YamlConfiguration.loadConfiguration(dataFile);
        getServer().getPluginManager().registerEvents(this, this);
        getCommand("setauthlobby").setExecutor(this);
    }
    private Location lobby() {
        World w = Bukkit.getWorld(getConfig().getString("lobby.world", "world")); if (w == null) return null;
        return new Location(w, getConfig().getDouble("lobby.x"), getConfig().getDouble("lobby.y", 100), getConfig().getDouble("lobby.z"),
            (float) getConfig().getDouble("lobby.yaw"), (float) getConfig().getDouble("lobby.pitch"));
    }
    private void save() { try { data.save(dataFile); } catch (IOException e) { getLogger().warning(e.getMessage()); } }

    @EventHandler(priority = EventPriority.MONITOR) public void onRequired(AuthRequiredEvent e) {
        Player p = e.getPlayer(); if (api.isAuthenticated(p)) return;
        String k = "saved." + p.getUniqueId();
        if (!data.contains(k)) { data.set(k + ".loc", p.getLocation()); data.set(k + ".gm", p.getGameMode().name()); save(); }
        Location l = lobby(); if (l != null) p.teleport(l);
        try { p.setGameMode(GameMode.valueOf(getConfig().getString("gamemode", "ADVENTURE").toUpperCase())); } catch (IllegalArgumentException ignored) {}
        if (getConfig().getBoolean("hide-players", true))
            for (Player o : Bukkit.getOnlinePlayers()) if (o != p) { p.hidePlayer(this, o); o.hidePlayer(this, p); }
    }
    @EventHandler public void onAuthenticated(PlayerAuthenticatedEvent e) {
        Player p = e.getPlayer(); String k = "saved." + p.getUniqueId();
        if (data.contains(k)) {
            try { p.setGameMode(GameMode.valueOf(data.getString(k + ".gm", "SURVIVAL"))); } catch (IllegalArgumentException ignored) {}
            Location back = getConfig().getBoolean("restore-location", true) ? data.getLocation(k + ".loc") : null;
            if (back == null) back = p.getWorld().getSpawnLocation();
            p.teleport(back);
            data.set(k, null); save();
        }
        for (Player o : Bukkit.getOnlinePlayers()) if (o != p && api.isAuthenticated(o)) { p.showPlayer(this, o); o.showPlayer(this, p); }
    }
    @Override public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (!(s instanceof Player p) || !p.hasPermission("authlobby.admin")) { s.sendMessage("Yetkin yok."); return true; }
        Location loc = p.getLocation();
        getConfig().set("lobby.world", loc.getWorld().getName()); getConfig().set("lobby.x", loc.getX()); getConfig().set("lobby.y", loc.getY());
        getConfig().set("lobby.z", loc.getZ()); getConfig().set("lobby.yaw", loc.getYaw()); getConfig().set("lobby.pitch", loc.getPitch());
        saveConfig(); p.sendMessage("Auth lobi konumu kaydedildi."); return true;
    }
}
