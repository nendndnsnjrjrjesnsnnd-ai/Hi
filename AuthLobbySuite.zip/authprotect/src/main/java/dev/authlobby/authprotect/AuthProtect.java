package dev.authlobby.authprotect;
import dev.authlobby.authcore.AuthApi;
import io.papermc.paper.event.player.AsyncChatEvent;
import dev.authlobby.authcore.event.PlayerAuthenticatedEvent;
import java.util.*;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.*;
import org.bukkit.plugin.java.JavaPlugin;
public final class AuthProtect extends JavaPlugin implements Listener {
    private AuthApi api; private Set<String> allowed;
    @Override public void onEnable() {
        saveDefaultConfig();
        api = Bukkit.getServicesManager().load(AuthApi.class);
        allowed = new HashSet<>(); for (String s : getConfig().getStringList("allowed-commands")) allowed = new HashSet<>(); for (String s : getConfig().getStringList("allowed-commands")) allowed.add(s.toLowerCase(Locale.ROOT));;
        getServer().getPluginManager().registerEvents(this, this);
    }
    private boolean un(Player p) { return !api.isAuthenticated(p); }
    @EventHandler(ignoreCancelled = true) public void onMove(PlayerMoveEvent e) {
        if (e instanceof PlayerTeleportEvent || !un(e.getPlayer()) || e.getTo() == null) return;
        Location f = e.getFrom(), t = e.getTo();
        if (f.getX() != t.getX() || f.getY() != t.getY() || f.getZ() != t.getZ()) {
            Location n = f.clone(); n.setYaw(t.getYaw()); n.setPitch(t.getPitch()); e.setTo(n);
        }
    }
    @EventHandler(ignoreCancelled = true) public void onCmd(PlayerCommandPreprocessEvent e) {
        if (!un(e.getPlayer())) return;
        String c = e.getMessage().substring(1).split(" ")[0].toLowerCase(Locale.ROOT);
        if (!allowed.contains(c)) { e.setCancelled(true); e.getPlayer().sendMessage(net.kyori.adventure.text.Component.text(getConfig().getString("blocked-message", "Önce giriş yap."))); }
    }
    // /server, /lobby vb. tüm komutları tab-complete listesinden de kaldır
    @EventHandler public void onCmdList(PlayerCommandSendEvent e) {
        if (un(e.getPlayer())) e.getCommands().removeIf(c -> !allowed.contains(c.toLowerCase(Locale.ROOT)));
    }
    @EventHandler public void onAuth(PlayerAuthenticatedEvent e) { e.getPlayer().updateCommands(); }
    @EventHandler public void onChat(AsyncChatEvent e) { if (un(e.getPlayer())) e.setCancelled(true); }
    @EventHandler public void onBreak(BlockBreakEvent e) { if (un(e.getPlayer())) e.setCancelled(true); }
    @EventHandler public void onPlace(BlockPlaceEvent e) { if (un(e.getPlayer())) e.setCancelled(true); }
    @EventHandler public void onInteract(PlayerInteractEvent e) { if (un(e.getPlayer())) e.setCancelled(true); }
    @EventHandler public void onInteractEntity(PlayerInteractEntityEvent e) { if (un(e.getPlayer())) e.setCancelled(true); }
    @EventHandler public void onDrop(PlayerDropItemEvent e) { if (un(e.getPlayer())) e.setCancelled(true); }
    @EventHandler public void onSwap(PlayerSwapHandItemsEvent e) { if (un(e.getPlayer())) e.setCancelled(true); }
    @EventHandler public void onPickup(EntityPickupItemEvent e) { if (e.getEntity() instanceof Player p && un(p)) e.setCancelled(true); }
    @EventHandler public void onInvClick(InventoryClickEvent e) { if (e.getWhoClicked() instanceof Player p && un(p)) e.setCancelled(true); }
    @EventHandler public void onInvOpen(InventoryOpenEvent e) { if (e.getPlayer() instanceof Player p && un(p)) e.setCancelled(true); }
    @EventHandler public void onFood(FoodLevelChangeEvent e) { if (e.getEntity() instanceof Player p && un(p)) e.setCancelled(true); }
    @EventHandler public void onDamaged(EntityDamageEvent e) { if (e.getEntity() instanceof Player p && un(p)) e.setCancelled(true); }
    @EventHandler public void onDamager(EntityDamageByEntityEvent e) { if (e.getDamager() instanceof Player p && un(p)) e.setCancelled(true); }
    @EventHandler public void onTarget(EntityTargetEvent e) { if (e.getTarget() instanceof Player p && un(p)) e.setCancelled(true); }
}
