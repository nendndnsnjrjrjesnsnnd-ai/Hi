package dev.authlobby.authsecurity;
import dev.authlobby.authcore.AuthApi;
import dev.authlobby.authcore.event.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
public final class AuthSecurity extends JavaPlugin implements Listener {
    private static final MiniMessage MM = MiniMessage.miniMessage();
    private final Map<UUID, Integer> fails = new ConcurrentHashMap<>();
    private final Map<String, Long> locks = new ConcurrentHashMap<>();
    private final Map<UUID, BukkitTask> timeouts = new ConcurrentHashMap<>();
    private AuthApi api;
    @Override public void onEnable() {
        saveDefaultConfig();
        api = Bukkit.getServicesManager().load(AuthApi.class);
        getServer().getPluginManager().registerEvents(this, this);
    }
    private static String ip(Player p) { return p.getAddress() == null ? "" : p.getAddress().getAddress().getHostAddress(); }
    private long lockedUntil(Player p) { return Math.max(locks.getOrDefault("u:" + p.getUniqueId(), 0L), locks.getOrDefault("i:" + ip(p), 0L)); }

    @EventHandler public void onPre(AuthPreAttemptEvent e) {
        if (e.getType() != AuthType.LOGIN) return;
        long left = lockedUntil(e.getPlayer()) - System.currentTimeMillis();
        if (left > 0) { e.setCancelled(true); e.setReason(getConfig().getString("messages.locked", "Kilitli: {seconds} sn").replace("{seconds}", String.valueOf(left / 1000 + 1))); }
    }
    @EventHandler public void onResult(AuthResultEvent e) {
        if (e.getType() != AuthType.LOGIN) return;
        Player p = e.getPlayer();
        if (e.isSuccess()) { fails.remove(p.getUniqueId()); return; }
        int n = fails.merge(p.getUniqueId(), 1, Integer::sum);
        if (n >= getConfig().getInt("max-attempts", 5)) {
            long until = System.currentTimeMillis() + getConfig().getLong("lock-minutes", 5) * 60_000L;
            locks.put("u:" + p.getUniqueId(), until); locks.put("i:" + ip(p), until); fails.remove(p.getUniqueId());
            p.kick(MM.deserialize(getConfig().getString("messages.kick-attempts", "<red>Çok fazla yanlış deneme.")));
        }
    }
    @EventHandler public void onPassword(PasswordCheckEvent e) {
        String pw = e.getPassword(); String r = null;
        if (pw.length() < getConfig().getInt("min-length", 6)) r = getConfig().getString("messages.too-short", "Çok kısa.");
        else if (pw.length() > getConfig().getInt("max-length", 64)) r = getConfig().getString("messages.too-long", "Çok uzun.");
        else if (pw.equalsIgnoreCase(e.getPlayer().getName())) r = getConfig().getString("messages.same-as-name", "İsminle aynı olamaz.");
        else for (String b : getConfig().getStringList("blacklist")) if (pw.equalsIgnoreCase(b)) { r = getConfig().getString("messages.too-common", "Çok yaygın."); break; }
        if (r != null) { e.setCancelled(true); e.setReason(r); }
    }
    @EventHandler(priority = EventPriority.MONITOR) public void onRequired(AuthRequiredEvent e) {
        Player p = e.getPlayer(); if (api.isAuthenticated(p)) return;
        cancel(p.getUniqueId());
        int secs = getConfig().getInt("login-timeout-seconds", 60); if (secs <= 0) return;
        timeouts.put(p.getUniqueId(), Bukkit.getScheduler().runTaskLater(this, () -> {
            timeouts.remove(p.getUniqueId());
            if (p.isOnline() && !api.isAuthenticated(p)) p.kick(MM.deserialize(getConfig().getString("messages.kick-timeout", "<red>Süre doldu.")));
        }, secs * 20L));
    }
    @EventHandler public void onAuth(PlayerAuthenticatedEvent e) { cancel(e.getPlayer().getUniqueId()); }
    @EventHandler public void onQuit(PlayerQuitEvent e) { cancel(e.getPlayer().getUniqueId()); }
    private void cancel(UUID id) { BukkitTask t = timeouts.remove(id); if (t != null) t.cancel(); }
}
