package dev.authlobby.authsession;
import dev.authlobby.authcore.AuthApi;
import dev.authlobby.authcore.event.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;
public final class AuthSession extends JavaPlugin implements Listener {
    private record Sess(String ip, long expires) {}
    private final Map<UUID, Sess> sessions = new ConcurrentHashMap<>();
    private AuthApi api;
    @Override public void onEnable() {
        saveDefaultConfig();
        api = Bukkit.getServicesManager().load(AuthApi.class);
        getServer().getPluginManager().registerEvents(this, this);
    }
    private static String ip(Player p) { return p.getAddress() == null ? "" : p.getAddress().getAddress().getHostAddress(); }
    @EventHandler(priority = EventPriority.LOW) public void onRequired(AuthRequiredEvent e) {
        if (!e.isRegistered()) return;
        Player p = e.getPlayer(); Sess s = sessions.remove(p.getUniqueId());
        if (s != null && s.expires() > System.currentTimeMillis() && s.ip().equals(ip(p))) api.forceLogin(p, "session");
    }
    @EventHandler(priority = EventPriority.LOWEST) public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        if (api.isAuthenticated(p)) sessions.put(p.getUniqueId(), new Sess(ip(p), System.currentTimeMillis() + getConfig().getLong("session-minutes", 30) * 60_000L));
    }
    @EventHandler public void onLogout(PlayerLogoutEvent e) { sessions.remove(e.getPlayer().getUniqueId()); }
}
