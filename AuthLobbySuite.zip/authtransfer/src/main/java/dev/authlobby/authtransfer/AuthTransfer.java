package dev.authlobby.authtransfer;
import dev.authlobby.authcore.event.PlayerAuthenticatedEvent;
import java.io.*;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.*;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
/** Giriş/kayıttan sonra büyük "AKTARILIYORSUN" başlığı + geri sayım, sonra ana sunucuya gönderir. Sayım sırasında oyuncu donar. */
public final class AuthTransfer extends JavaPlugin implements Listener {
    private static final MiniMessage MM = MiniMessage.miniMessage();
    private final Map<UUID, BukkitTask> running = new ConcurrentHashMap<>();
    @Override public void onEnable() {
        saveDefaultConfig();
        getServer().getMessenger().registerOutgoingPluginChannel(this, "BungeeCord");
        getServer().getPluginManager().registerEvents(this, this);
    }
    @EventHandler public void onAuth(PlayerAuthenticatedEvent e) {
        if (!getConfig().getBoolean("enabled", true)) return;
        if (e.getMethod().equals("session") && !getConfig().getBoolean("on-session", true)) return;
        Player p = e.getPlayer();
        int total = Math.max(1, getConfig().getInt("countdown-seconds", 3));
        int[] left = {total};
        cancel(p.getUniqueId());
        running.put(p.getUniqueId(), Bukkit.getScheduler().runTaskTimer(this, () -> {
            if (!p.isOnline()) { cancel(p.getUniqueId()); return; }
            if (left[0] <= 0) { cancel(p.getUniqueId()); send(p); return; }
            p.showTitle(Title.title(MM.deserialize(getConfig().getString("title", "<bold>AKTARILIYORSUN")),
                MM.deserialize(getConfig().getString("subtitle", "{seconds}").replace("{seconds}", String.valueOf(left[0]))),
                Title.Times.times(Duration.ZERO, Duration.ofMillis(1100), Duration.ZERO)));
            p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 0.8f + 0.4f * (total - left[0]) / total);
            left[0]--;
        }, 10L, 20L)); // kısa gecikmeden sonra her saniye
    }
    private void send(Player p) {
        if (getConfig().getString("mode", "proxy").equalsIgnoreCase("transfer")) {
            p.transfer(getConfig().getString("transfer.host", "127.0.0.1"), getConfig().getInt("transfer.port", 25565));
            return;
        }
        try {
            ByteArrayOutputStream b = new ByteArrayOutputStream(); DataOutputStream o = new DataOutputStream(b);
            o.writeUTF("Connect"); o.writeUTF(getConfig().getString("proxy.server", "lobby"));
            p.sendPluginMessage(this, "BungeeCord", b.toByteArray());
        } catch (IOException ex) { getLogger().warning(ex.getMessage()); }
    }
    private void cancel(UUID id) { BukkitTask t = running.remove(id); if (t != null) t.cancel(); }
    private boolean frozen(Player p) { return running.containsKey(p.getUniqueId()); }

    // sayım sırasında hareket/komut/etkileşim yok
    @EventHandler public void onMove(PlayerMoveEvent e) {
        if (e instanceof PlayerTeleportEvent || !frozen(e.getPlayer()) || e.getTo() == null) return;
        var f = e.getFrom(); var t = e.getTo();
        if (f.getX() != t.getX() || f.getY() != t.getY() || f.getZ() != t.getZ()) { var n = f.clone(); n.setYaw(t.getYaw()); n.setPitch(t.getPitch()); e.setTo(n); }
    }
    @EventHandler public void onCmd(PlayerCommandPreprocessEvent e) { if (frozen(e.getPlayer())) e.setCancelled(true); }
    @EventHandler public void onInteract(PlayerInteractEvent e) { if (frozen(e.getPlayer())) e.setCancelled(true); }
    @EventHandler public void onDamage(EntityDamageEvent e) { if (e.getEntity() instanceof Player p && frozen(p)) e.setCancelled(true); }
    @EventHandler public void onQuit(PlayerQuitEvent e) { cancel(e.getPlayer().getUniqueId()); }
}
