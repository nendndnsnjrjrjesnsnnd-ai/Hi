package dev.authlobby.authui;
import dev.authlobby.authcore.AuthApi;
import dev.authlobby.authcore.event.*;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.*;
import org.bukkit.scheduler.BukkitTask;
public final class AuthUI extends JavaPlugin implements Listener {
    private static final MiniMessage MM = MiniMessage.miniMessage();
    private final Map<UUID, BukkitTask> tasks = new ConcurrentHashMap<>();
    private final Map<UUID, BossBar> bars = new ConcurrentHashMap<>();
    private AuthApi api;
    @Override public void onEnable() {
        saveDefaultConfig();
        api = Bukkit.getServicesManager().load(AuthApi.class);
        getServer().getPluginManager().registerEvents(this, this);
    }
    private Component m(String k, String... kv) { return MM.deserialize(rep(getConfig().getString("messages." + k, k), kv)); }
    private static String rep(String s, String... kv) { for (int i = 0; i + 1 < kv.length; i += 2) s = s.replace("{" + kv[i] + "}", kv[i + 1]); return s; }

    /** "başlık | alt başlık" satırını yavaşça beliren (fade-in) title olarak gösterir. */
    private void guideStep(Player p, String line) {
        String[] parts = rep(line, "player", p.getName()).split("\\|", 2);
        int in = getConfig().getInt("guide.fade-in-seconds", 3), stay = getConfig().getInt("guide.stay-seconds", 3), out = getConfig().getInt("guide.fade-out-seconds", 1);
        p.showTitle(Title.title(MM.deserialize(parts[0].trim()), MM.deserialize(parts.length > 1 ? parts[1].trim() : ""),
            Title.Times.times(Duration.ofSeconds(in), Duration.ofSeconds(stay), Duration.ofSeconds(out))));
    }

    @EventHandler(priority = EventPriority.MONITOR) public void onRequired(AuthRequiredEvent e) {
        Player p = e.getPlayer(); if (api.isAuthenticated(p)) return;
        cleanup(p);
        final boolean reg = e.isRegistered();
        final boolean dialog = api.usesDialog(p);
        if (getConfig().getBoolean("blindness", true))
            p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, PotionEffect.INFINITE_DURATION, 0, false, false, false));
        final int total = getConfig().getInt("timeout-seconds", 60);
        BossBar bar = BossBar.bossBar(m("bossbar", "seconds", String.valueOf(total)), 1f, BossBar.Color.YELLOW, BossBar.Overlay.PROGRESS);
        bars.put(p.getUniqueId(), bar);
        if (total > 0) p.showBossBar(bar);

        // Eski sürüm (komut modu): döngüde yavaş beliren rehber. 1.21.6+: tek karşılama başlığı (menü zaten açık).
        final List<String> steps = getConfig().getStringList("guide." + (reg ? "login" : "register"));
        final int stepLen = Math.max(1, getConfig().getInt("guide.fade-in-seconds", 3) + getConfig().getInt("guide.stay-seconds", 3) + getConfig().getInt("guide.fade-out-seconds", 1));
        if (!steps.isEmpty()) guideStep(p, steps.get(0));
        final int[] sec = {0}, left = {total};
        tasks.put(p.getUniqueId(), Bukkit.getScheduler().runTaskTimer(this, () -> {
            if (!p.isOnline() || api.isAuthenticated(p)) { cleanup(p); return; }
            sec[0]++;
            if (total > 0 && left[0] > 0) { left[0]--; bar.progress(Math.max(0f, left[0] / (float) total)); bar.name(m("bossbar", "seconds", String.valueOf(left[0]))); }
            p.sendActionBar(m(dialog ? (reg ? "actionbar-login-dialog" : "actionbar-register-dialog") : (reg ? "actionbar-login" : "actionbar-register")));
            if (!dialog && !steps.isEmpty() && sec[0] % stepLen == 0) guideStep(p, steps.get((sec[0] / stepLen) % steps.size()));
        }, 20L, 20L));
    }
    @EventHandler public void onAuth(PlayerAuthenticatedEvent e) {
        Player p = e.getPlayer(); cleanup(p);
        if (getConfig().getBoolean("welcome-title", false)) {
        p.clearTitle();
        p.showTitle(Title.title(m("title-welcome"), m("subtitle-welcome", "player", p.getName()), Title.Times.times(Duration.ofMillis(500), Duration.ofSeconds(2), Duration.ofMillis(800))));
        }
        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
    }
    @EventHandler public void onQuit(PlayerQuitEvent e) { cleanup(e.getPlayer()); }
    private void cleanup(Player p) {
        BukkitTask t = tasks.remove(p.getUniqueId()); if (t != null) t.cancel();
        BossBar b = bars.remove(p.getUniqueId()); if (b != null) p.hideBossBar(b);
        p.removePotionEffect(PotionEffectType.BLINDNESS);
    }
}
